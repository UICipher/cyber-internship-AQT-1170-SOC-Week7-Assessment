# Week 7 Labs — Roman Urdu Explanation

## Overall idea

Is week ka main focus SOC aur Blue Team ka practical workflow tha. SOC ka matlab Security Operations Center hai. SOC analyst alerts monitor karta hai, logs ko check karta hai, suspicious activity ko samajhta hai, phir evidence ki bunyaad par verdict deta hai ke alert genuine hai, false positive hai, benign hai ya escalation ki zaroorat hai.

Sab se important baat yeh hai ke sirf aik log line dekh kar decision nahi lena. Pehle evidence collect karna hota hai, phir timeline aur related events ko correlate karna hota hai.

## Lab 1 — SOC Fundamentals

Pehle TryHackMe ka SOC Fundamentals room complete kiya. Is mein SOC ke roles, People/Process/Technology model, detection aur response ka difference, alert triage aur reporting samjhi.

SOC mein **People** analysts aur responders hote hain. **Process** se murad documented workflow hota hai, jaise alert ko assign karna, investigate karna, verdict dena aur close ya escalate karna. **Technology** mein SIEM, endpoint monitoring, network logs aur detection tools aate hain.

Is lab ke practical exercise mein port-scanning alert investigate kiya gaya. Alert ka naam tha **Port Scanning Activity Detected from IP: 10.0.0.8**. Port scan ka matlab hota hai ke koi source multiple ports ya services ko probe kar raha hai. Is se attacker ko network discovery mein madad mil sakti hai.

Is alert ko samajhne ke liye 5 Ws use kiye:

- **What:** Port-scanning activity detect hui.
- **When:** Lab record mein 12 June 2024, 17:24 show hua.
- **Where:** Source IP 10.0.0.8.
- **Who:** Source IP maloom hai, lekin human user ya process confirm karne ke liye additional logs chahiye.
- **Why:** Port scanning discovery phase ka hissa ho sakti hai, is liye suspicious hai, lekin sirf is alert se compromise prove nahi hota.

Is lab se yeh samajh aaya ke L1 analyst ka kaam alert ko blindly close karna nahi, balki context check karna hota hai. Room completion screenshot mein 7 tasks aur 128 points show hue.

## Lab 2 — SOC L1 Alert Triage

Doosre lab mein alert triage ka complete workflow seekha: **event → log → alert → investigation → verdict**.

Sab se pehle alerts ko priority deni hoti hai. High severity aur purane alerts ko relevant context ke saath review karte hain. Lab mein correct answer ke taur par **Potential Data Exfiltration** ko first-priority alert select kiya gaya.

Alert triage ka practical flow yeh hai:

**New → Assigned → Investigating → Verdict → Close ya Escalate**

Investigation ke waqt alert name, time, severity, status, assignee, host, user, process, target file, URL, hash aur related events check karte hain.

### Main case: Double-Extension File Creation

Main case **Double-Extension File Creation** tha. Alert ka time 21 March 2025, 13:58 tha. Severity High thi. File ka naam **cats2025.mp4.exe** tha aur source domain **freecatvideoshd.monster** show hua. MD5 value bhi record mein thi.

Double extension ka matlab hai file ka naam dekhne mein video jaisa lagta hai, lekin asli last extension `.exe` hoti hai. Operating system ke liye `.exe` executable file hoti hai. Is technique ka use phishing ya malware delivery mein ho sakta hai, kyun ke user samajhta hai ke woh video open kar raha hai.

Is alert ko **True Positive** is liye classify kiya gaya kyun ke:

1. File ka naam misleading tha.
2. Last extension `.exe` thi.
3. Download untrusted domain se tha.
4. Alert rule specifically double-extension file creation detect kar raha tha.
5. Hash aur URL ko further investigation ke liye use kiya ja sakta hai.

Lekin yeh bhi yaad rakhna hai ke alert se execution automatically prove nahi hoti. Production investigation mein process tree, user, browser history, proxy logs, DNS logs, EDR events aur outbound connections bhi check karne honge.

Agar file execute hui ho, persistence mili ho, ya lateral movement ka evidence ho, to endpoint isolate karke L2 ya incident response team ko escalate karna chahiye. Agar file download par hi block ho gayi aur execution ka koi evidence na ho, to case ko evidence ke saath close kiya ja sakta hai.

Is room ka completion screenshot 6 tasks aur 80 points show karta hai.

## Lab 3 — BTLO The Report II

Teesra practical Blue Team Labs Online ka **The Report II** challenge tha. Is ka scenario ek naye SOC ko improve karne aur MITRE ki report se useful outcomes suggest karne par based tha.

Challenge mein yeh concepts complete kiye:

- Network aur IT equipment ke liye **NOC**
- Incident detection and response ke liye **SOC**
- Compliance aur risk measurement ke liye **ICM**
- Response options: **Block Activity, Deactivate Account, Continue Watching, Refer to Outside Party**
- Situational awareness ke liye **OODA Loop**
- 1000 se 10,000 employees ke liye **Distributed SOC** model
- Large Centralised SOC mein **SOC Operations Lead**
- Optional capabilities: **Deception** aur **Insider Threat**
- Virtual console technologies: **iLO** aur **iDRAC**

Is challenge ka main lesson yeh hai ke SOC sirf tools ka naam nahi. SOC ko clear roles, documented processes, response decisions, metrics aur situational awareness chahiye hoti hai.

## Timeline kaise banayi

Timeline banate waqt alerts ko time ke order mein arrange kiya. Queue mein yeh records nazar aaye:

1. 11:53 — Bruteforce Attack from External
2. 12:40 — Unusual VPN Login Location
3. 13:02 — Download alert
4. 13:30 — Potential Data Exfiltration priority selection
5. 13:58 — Double-Extension File Creation
6. Review ke baad — L1 assignment, investigation aur True Positive / Closed verdict

Pehle paanch timestamps lab interface se liye gaye. Aakhri row analyst workflow ko show karti hai, raw endpoint event nahi. Report mein yeh distinction mention karna zaroori hai taake evidence overclaim na ho.

## Event, Alert aur Incident ka difference

**Event:** Koi individual observation, jaise file create hona ya failed login.

**Alert:** Detection rule ka notification jo analyst ko review ke liye diya jata hai.

**Incident:** Confirmed ya highly credible security situation jisko coordinated response chahiye hota hai.

Har alert incident nahi hota. Investigation ke baad alert false positive ya benign bhi ho sakta hai.

## False positive kya hota hai

False positive woh alert hai jo suspicious lagta hai lekin context check karne par benign prove hota hai. Lab mein Unusual VPN Login Location ko False Positive mark kiya gaya.

## SIEM ka purpose

SIEM multiple sources se logs collect aur normalize karta hai. Yeh detection rules run karta hai, alerts generate karta hai, correlation mein madad deta hai aur analyst ko investigation ka central interface provide karta hai.

## Kab escalate karna hai

Agar malware execution confirm ho, privileged account involve ho, lateral movement ya data loss ka chance ho, persistence milay, ya evidence incomplete ho lekin possible impact high ho, to L1 analyst ko alert close nahi karna chahiye. Isay L2 ya incident response team ko escalate karna chahiye.

## Dost ko short mein kaise samjhana hai

Tum yeh keh sakte ho:

“Week 7 mein maine pehle SOC fundamentals seekhe aur port-scanning alert ko 5 Ws se analyse kiya. Phir L1 alert triage lab mein severity aur alert age ke basis par priority set ki, surrounding events dekhe aur double-extension file alert investigate kiya. `cats2025.mp4.exe` suspicious tha kyun ke file video jaisi lagti hai lekin actually executable hai aur untrusted domain se aayi thi. Is liye lab mein verdict High-severity True Positive diya. Lekin real incident mein execution, process tree, hash, DNS, proxy aur endpoint logs bhi check karne padte hain. Teesre BTLO challenge mein SOC roles, response options, OODA Loop aur SOC organisational model samjha. Main conclusion yeh hai ke SOC analyst ko evidence aur correlation ke basis par decision lena chahiye, sirf ek log entry par nahi.”

## Viva ke liye important points

Agar instructor pooche ke important log ya alert kya tha, to Double-Extension File Creation explain karo. Agar pooche verdict kyun True Positive tha, to filename, `.exe` extension, untrusted domain aur detection rule explain karo. Agar pooche next action kya hoga, to endpoint isolation if executed, hash search, process tree, DNS/proxy review aur escalation explain karo.

![AstraQuantum Tech](assets/aqt-mark.svg)

# Week 7 — SOC / Blue Team Assessment

## Logging • Monitoring • Log Analysis • Alert Investigation • Incident Response

**Student:** Muahmmad Umer Imran  
**Student ID:** AQT-1170  
**Instructor / Mentor:** Muhammad Ehtisham  
**Organization:** AstraQuantum Tech  
**Assessment date:** 25 September 2026  

> **Submission links**  
> GitHub repository: **[Insert GitHub repository link]**  
> LinkedIn post: **[Insert LinkedIn post link]**

---

## Executive Summary

This assessment documents practical work completed in authorized training environments for Week 7 of the AstraQuantum Tech Summer of Cybersecurity 2026 program. The work covered SOC fundamentals, Level 1 alert triage, log-based reasoning, incident-response decisions, and a defensive Blue Team Labs Online challenge.

The submitted evidence shows completion of the **TryHackMe SOC Fundamentals** room, completion of the **TryHackMe SOC L1 Alert Triage** room, and completion of the BTLO challenge **The Report II**. During triage, I prioritised alerts using severity and age, reviewed the surrounding context, and selected **Double-Extension File Creation** as the primary case for deeper investigation. The available evidence supports a **High-severity True Positive** verdict because the alert describes a file named `cats2025.mp4.exe`, downloaded from an untrusted domain, with a double extension designed to make an executable appear to be a video file.

The assessment also demonstrates a clear distinction between a raw event, an alert, and an incident. A single event is not treated as proof of compromise. Instead, the verdict is based on the alert description, file naming pattern, source domain, hash value, host context, process/user context, and the recommended follow-up actions.

## 1. Scope and Authorized Environment

All activity described in this report was performed inside the training platforms specified by the assignment. No real organization, production endpoint, or public system was investigated. The evidence set supplied for review contains browser screenshots from TryHackMe and Blue Team Labs Online, together with the assignment brief.

The report covers three practical activities:

1. **TryHackMe — SOC Fundamentals**, including SOC roles, People/Process/Technology, detection and response, alert handling, and a port-scanning practical exercise.
2. **TryHackMe — SOC L1 Alert Triage**, including event-to-alert reasoning, severity and age-based prioritisation, alert ownership, investigation, and verdict handling.
3. **Blue Team Labs Online — The Report II**, a defensive challenge focused on SOC structure, response options, organisational models, situational awareness, and operational capabilities.

## 2. Tools and Platforms Used

| Platform or tool | Use in this assessment |
|---|---|
| TryHackMe | SOC Fundamentals and SOC L1 Alert Triage practical rooms |
| Blue Team Labs Online | The Report II defensive challenge |
| Browser-based lab interfaces | Review of alerts, task answers, status, and completion evidence |
| SIEM-style alert interface | Alert fields, severity, status, assignee, verdict, host, process, target file, and hash review |
| Screenshot evidence | Verification of student activity, lab context, results, and system date/time |

## 3. Practical Activity Summaries

### 3.1 TryHackMe SOC Fundamentals

The SOC Fundamentals room introduced the operational purpose of a Security Operations Center and the responsibilities of an L1 analyst. The practical work connected SOC roles with the People, Process, and Technology model. It also demonstrated how an analyst moves from detection to alert review, investigation, reporting, and closure or escalation.

The practical alert exercise focused on a port-scanning alert. The alert list showed **“Port Scanning Activity Detected from IP: 10.0.0.8”**, marked as a network and high-severity alert. The room completion screen recorded **7 completed tasks and 128 points**. The exercise reinforced that an L1 analyst must identify what happened, when it happened, where it occurred, who was involved, and why the activity was suspicious before making a decision.

**L1 analyst summary:** An L1 SOC analyst monitors alerts, validates whether an alert is meaningful, collects the surrounding evidence, records the investigation clearly, and assigns an initial verdict. The analyst should not close an alert merely because one log line appears harmless. The analyst should correlate time, source, destination, account, process, and related events. If the evidence indicates a likely attack, material impact, or insufficient information for a safe closure, the alert should be escalated with a concise evidence-based handoff. If the evidence demonstrates expected activity or a known benign explanation, the alert can be closed as benign or false positive with the reasoning documented.

**Five Ws for the port-scanning alert:**

- **What:** Network port-scanning activity was detected.
- **When:** The lab alert record displayed the event as **12 June 2024 at 17:24**.
- **Where:** The source shown in the alert was **10.0.0.8**, within the lab network context.
- **Who:** The visible alert identified the source IP rather than a confirmed human user. The responsible process or account would require additional host and network telemetry.
- **Why:** A port scan probes multiple services and can be used for discovery before exploitation. It is suspicious in the absence of an approved scanning purpose, but the alert alone does not prove that a compromise occurred.

### 3.2 TryHackMe SOC L1 Alert Triage

The SOC L1 Alert Triage room focused on the workflow from **event → log → alert → investigation → verdict**. I used the room’s prioritisation logic by reviewing severity and alert age before selecting an alert for investigation. The evidence shows the correct prioritisation responses and the selection of **Potential Data Exfiltration** as the first-priority alert. The room completion evidence records **6 completed tasks and 80 points**.

The detailed alert review also covered a **Double-Extension File Creation** alert dated **21 March 2025 at 13:58**. The record showed **High** severity, a closed status after review, and a **True Positive** verdict. The alert description explained that files such as `*.pdf.exe` or `*.gif.lnk` may be used to disguise executables and trick a user into opening them.

### 3.3 Blue Team Labs Online — The Report II

The selected BTLO challenge was **The Report II**, a medium-difficulty defensive challenge worth 20 points. Its scenario asked the analyst to study a MITRE report and recommend useful outcomes for a newly established SOC. The completed evidence shows correct answers covering the short-form teams **NOC, SOC, ICM**; the response options **Block Activity, Deactivate Account, Continue Watching, Refer to Outside Party**; the **OODA Loop**; a distributed SOC organisational model; the SOC Operations Lead role; the optional capabilities **Deception** and **Insider Threat**; and the virtual console technologies **iLO and iDRAC**.

The challenge objective was to connect SOC design with operational readiness. The key learning outcome was that an effective SOC requires defined responsibilities, repeatable workflows, situational awareness, measurable operations, and response options that are appropriate to the evidence and impact.

## 4. Alert Investigation Case Report

### Case identification

| Field | Finding |
|---|---|
| Case ID / Alert ID | TryHackMe SOC L1 Alert Triage — Double-Extension File Creation, 21 March 2025 13:58 |
| Alert name | Double-Extension File Creation |
| Severity | High |
| Detection source | SIEM-style file-creation detection rule in the TryHackMe training environment |
| Status | Closed after investigation in the lab |
| Verdict | True Positive |

### Executive summary

A high-severity alert identified the creation or download of a double-extension file named **`cats2025.mp4.exe`**. The file was associated with the untrusted domain **`freecatvideoshd.monster`** and the visible record included the MD5 value **`14d8486f3f63875ef93cfd240c5dc10b`**. The `.mp4.exe` naming pattern is a classic attempt to make an executable look like a video file. The untrusted source and the executable extension increase the likelihood that the file is malicious or part of a phishing delivery chain. The correct lab verdict was **True Positive**, with containment and endpoint investigation recommended.

### 5 Ws analysis

| Question | Analysis |
|---|---|
| **What happened?** | A suspicious double-extension executable, `cats2025.mp4.exe`, was downloaded or created. |
| **When did it happen?** | The alert record displayed **21 March 2025 at 13:58**. |
| **Where did it happen?** | The event occurred in the training environment on the host represented by the alert record. The supplied screenshot does not expose a readable host name, so the host should be obtained from the underlying SIEM record before a real containment decision. |
| **Who was involved?** | The immediate entities were the endpoint user/process that created or downloaded the file and the external domain `freecatvideoshd.monster`. The exact user and process should be confirmed from endpoint telemetry. |
| **Why is it suspicious?** | The filename uses a misleading media extension followed by `.exe`, and the source domain is untrusted. This combination is consistent with a phishing or malware-delivery technique. |
| **Which logs support the conclusion?** | The SIEM alert record, file-creation telemetry, download/proxy history, endpoint process history, DNS/network logs, and hash reputation data should be correlated. The screenshot directly confirms the alert description, URL, file name, and MD5 value. |
| **What happened immediately before and after?** | Before the alert, a user or process likely accessed the external domain and initiated a download. After the alert, the analyst reviewed the record, assigned a True Positive verdict, and closed the lab alert. In a production investigation, process execution, persistence, additional downloads, and outbound connections would be checked next. |

### Evidence and correlation

The most important evidence is the combination of the file name and source context. A file named `cats2025.mp4.exe` is not simply a media file; the final executable extension controls how the operating system may treat it. The domain shown in the record is not an established trusted software distribution source. The MD5 value provides a correlation key for endpoint search and threat-intelligence lookup, although a hash alone should not be treated as proof of maliciousness.

The investigation should therefore correlate the alert with the endpoint’s process tree, the user who initiated the download, browser history, DNS resolution, proxy logs, antivirus or EDR detections, and any child process created after the file appeared. This approach follows the assessment principle of evidence before assumptions.

### Verdict and severity rationale

**Verdict: True Positive.** The lab evidence is sufficient to classify the detection as a genuine suspicious file event rather than a false positive. **Severity: High.** The file is an executable disguised as a video and was sourced from an untrusted domain. The severity would be raised further if the file executed, established persistence, contacted a command-and-control endpoint, or affected a privileged account.

### Impact assessment

The immediate potential impact is endpoint compromise through user execution of a disguised executable. Possible consequences include credential theft, malware installation, persistence, lateral movement, data access, or further payload retrieval. The supplied evidence does not prove execution or successful compromise. Therefore, the confirmed finding is a high-risk malicious-looking file event, while the scope of any resulting incident remains subject to endpoint and network correlation.

### Recommended response

The affected endpoint should be isolated if the file executed or if additional telemetry indicates compromise. The file should be quarantined, and the hash should be searched across endpoints. Analysts should collect the process tree, user identity, browser and proxy history, DNS records, EDR events, persistence locations, and outbound network connections. The source domain should be blocked through the appropriate secure web gateway or DNS control after confirming that it is not required for an approved business purpose. Credentials should be reset only when evidence suggests that the user or endpoint was exposed.

The case should be escalated to L2 or incident response when execution is confirmed, when the endpoint shows persistence or lateral movement, when a privileged account is involved, or when the evidence is incomplete but the potential impact is material. If the file was blocked before execution and no related activity is found, the case can be closed with the evidence and prevention action documented.

## 5. Alert Triage Workflow

The working triage flow used for the assessment was:

**New → Assigned → Investigating → Verdict → Close / Escalate**

At the investigation stage, the analyst checks the alert name, timestamp, severity, status, assignee, host, account, process, target file, source or destination, related events, and available hash or URL data. A verdict is then selected only after the evidence is compared with expected activity and surrounding events.

## 6. Incident Timeline

| Time | Event | Evidence source | Why it matters |
|---|---|---|---|
| 21 Mar 2025, 11:53 | A separate **Bruteforce Attack from External** alert appears in the triage records. | Alert table screenshot | Establishes surrounding alert activity and the need to review the queue chronologically. |
| 21 Mar 2025, 12:40 | **Unusual VPN Login Location** is recorded and later marked False Positive. | Alert table and task-answer screenshot | Demonstrates that an alert can be suspicious-looking but benign after contextual review. |
| 21 Mar 2025, 13:02 | A **Download** alert appears in the queue. | Alert table screenshot | Provides a nearby event that could be correlated with later file activity. |
| 21 Mar 2025, 13:30 | **Potential Data Exfiltration** is selected as the first-priority alert in the room workflow. | Alert-prioritisation screenshot | Shows severity-and-age-based triage rather than opening alerts randomly. |
| 21 Mar 2025, 13:58 | **Double-Extension File Creation** is recorded as High severity. | Detailed alert screenshot | Identifies the primary case and the suspicious `cats2025.mp4.exe` file. |
| 21 Mar 2025, after review | The alert is assigned to the L1 analyst, investigated, and marked **True Positive / Closed** in the training interface. | Alert detail and completion evidence | Records the analyst decision and demonstrates the full triage lifecycle. |

The first five timestamps are displayed in the triage queue. The final row represents the documented analyst workflow and verdict shown in the supplied evidence; it is not presented as a separate raw endpoint log event.

## 7. Evidence and Screenshots

The following exhibits are selected from the submitted screenshots. They show the training platform, the student’s own results, and, where visible, the system date and time. Screenshots from walkthroughs or third-party material were not used as completion evidence.

### Exhibit 1 — SOC Fundamentals alert record

![SOC Fundamentals alert record](assets/exhibit-1-soc-alert.png)

*Caption: The SIEM-style lab interface shows the port-scanning alert from `10.0.0.8`, with high severity and a resolved/closed state. The screenshot also shows the lab flag generated after the student completed the exercise.*

### Exhibit 2 — SOC Fundamentals completion

![SOC Fundamentals completion](assets/exhibit-2-soc-completion.png)

*Caption: TryHackMe completion evidence for SOC Fundamentals. The page records seven completed tasks and 128 points. The system date/time is visible at the bottom of the screenshot.*

### Exhibit 3 — Alert prioritisation

![Alert prioritisation](assets/exhibit-3-triage-priority.png)

*Caption: The SOC L1 Alert Triage room confirms the prioritisation logic and the selection of Potential Data Exfiltration as the first-priority alert. The answers are marked correct.*

### Exhibit 4 — Double-extension case details

![Double-extension case details](assets/exhibit-4-double-extension.png)

*Caption: The detailed alert record shows High severity, the True Positive verdict, the suspicious `cats2025.mp4.exe` target, the untrusted domain, and the MD5 value used for further correlation.*

### Exhibit 5 — SOC L1 Alert Triage completion

![SOC L1 Alert Triage completion](assets/exhibit-5-triage-completion.png)

*Caption: TryHackMe completion evidence for SOC L1 Alert Triage. The page records six completed tasks and 80 points.*

### Exhibit 6 — BTLO challenge scenario

![BTLO challenge scenario](assets/exhibit-6-btlo-scenario.png)

*Caption: Blue Team Labs Online shows the selected challenge, The Report II, and its SOC improvement scenario.*

### Exhibit 7 — BTLO completed answers

![BTLO completed answers](assets/exhibit-7-btlo-answers.png)

*Caption: The challenge interface marks the submitted answers as correct, including NOC/SOC/ICM, the response options, OODA Loop, distributed SOC, SOC Operations Lead, Deception/Insider Threat, and iLO/iDRAC.*

### Exhibit 8 — BTLO completion evidence

![BTLO completion evidence](assets/exhibit-8-btlo-completion.png)

*Caption: The supplied BTLO completion screenshot confirms the student’s challenge result in the platform context.*

## 8. Assessment Questions

**1. What is the difference between a raw event, an alert, and an incident?** A raw event is an individual observation, such as a file creation or failed login. An alert is a detection rule’s notification that one or more events deserve review. An incident is a confirmed or sufficiently credible security situation that requires coordinated response.

**2. Why are timestamps important when correlating logs?** Timestamps place events in sequence and help the analyst identify what happened before and after an alert. They also reveal whether records from different sources refer to the same activity. Time-zone differences and clock drift must be considered.

**3. Why can one log entry be misleading without surrounding events?** A single entry may be caused by an approved task, a scanner, a shared system, or a normal user action. The surrounding account, host, process, network, and authentication activity provides the context needed to distinguish normal behavior from attack activity.

**4. What is a false positive? Give a SOC example.** A false positive is an alert that resembles suspicious behavior but is shown to be benign after investigation. In this lab, the Unusual VPN Login Location alert was marked False Positive after review.

**5. What is the purpose of a SIEM?** A SIEM centralizes and normalizes security-relevant logs, applies detection rules, supports correlation, and gives analysts a place to investigate alerts and document decisions.

**6. When should an L1 analyst escalate instead of closing an alert?** Escalation is appropriate when malicious activity is likely, when execution or compromise is confirmed, when a privileged asset is involved, when there is possible lateral movement or data loss, or when the evidence is insufficient for a safe closure and the potential impact is significant.

**7. What evidence should be collected before recommending containment?** The analyst should collect the alert record, timestamps, affected host and user, process tree, file path and hash, authentication events, DNS and network connections, proxy or browser history, related endpoint detections, persistence indicators, and evidence of execution or lateral movement.

## 9. Conclusion

This Week 7 assessment demonstrates practical progress from basic SOC concepts to evidence-based alert investigation. The work shows that triage is not simply a process of opening the highest-severity alert. It requires prioritisation, context, correlation, clear separation of event and incident, and a documented verdict.

The primary case study, Double-Extension File Creation, was correctly classified as a High-severity True Positive in the training environment. The next professional step would be to validate execution, scope the affected endpoint, search the hash and domain across the environment, and escalate when the evidence indicates a broader incident. This approach keeps the investigation concise, defensible, and aligned with L1 SOC responsibilities.

## Appendix A — Submission Checklist

| Requirement | Status |
|---|---|
| SOC Fundamentals completed | Included; completion screenshot shows 7 tasks and 128 points |
| SOC L1 Alert Triage completed | Included; completion screenshot shows 6 tasks and 80 points |
| One free BTLO defensive challenge completed | Included; The Report II evidence is attached |
| Own screenshots and date/time evidence | Included; system date/time is visible in supplied screenshots |
| One investigated alert | Included; Double-Extension File Creation |
| 6+ event incident timeline | Included; six documented timeline rows |
| 5 Ws analysis | Included |
| Professional SOC investigation report | Included |
| GitHub repository link | **[Insert link before submission]** |
| LinkedIn post link | **[Insert link before submission]** |

## References

[1]: https://tryhackme.com/room/socfundamentals "TryHackMe SOC Fundamentals"

[2]: https://tryhackme.com/room/socl1alerttriage "TryHackMe SOC L1 Alert Triage"

[3]: https://blueteamlabs.online/home/challenge/the-report-ii-82ea7781c5 "Blue Team Labs Online — The Report II"

[4]: https://www.mitre.org/sites/default/files/publications/11-strategies-of-a-world-class-cybersecurity-operations-center.pdf "MITRE — 11 Strategies of a World-Class Cybersecurity Operations Center"

---

**Prepared for academic submission by Muahmmad Umer Imran (AQT-1170).**

*Replace the two bold link placeholders on the cover page and in the checklist after publishing the GitHub repository and LinkedIn post.*

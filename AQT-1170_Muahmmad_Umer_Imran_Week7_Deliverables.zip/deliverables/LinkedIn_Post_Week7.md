# LinkedIn Post — Week 7 SOC / Blue Team Assessment

A meaningful step forward in my cybersecurity learning journey: I have completed **Week 7 of the AstraQuantum Tech Summer of Cybersecurity 2026 program**, focused on Security Operations Center work and Blue Team investigation.

This week moved beyond theory into an analyst-style workflow. I completed practical activities on:

- SOC roles, People/Process/Technology, detection, response, and reporting
- L1 alert triage using severity, age, context, and surrounding events
- Log correlation and the distinction between an event, an alert, and an incident
- A defensive Blue Team Labs Online challenge on SOC structure and operational improvement

For my investigation case, I analysed a **Double-Extension File Creation** alert involving a suspicious `cats2025.mp4.exe` file downloaded from an untrusted domain. Based on the available evidence, I documented the case as a **High-severity True Positive** in the training environment and outlined the next steps an analyst would take: verify execution, review the process tree, search the hash across endpoints, correlate DNS and proxy data, and escalate when the evidence indicates broader compromise.

The biggest lesson from this exercise was simple but important: **a single log line is not a complete investigation**. Good SOC work depends on evidence, timeline, correlation, careful wording, and a defensible verdict.

I am grateful to **Muhammad Ehtisham**, my instructor and mentor, for the guidance and practical direction throughout this learning process. Thank you to **AstraQuantum Tech** for creating a structured environment where cybersecurity concepts can be turned into repeatable analyst skills.

I have documented the work, evidence, and investigation methodology in my GitHub repository:

**GitHub:** [Insert repository link]

#CyberSecurity #SOC #BlueTeam #IncidentResponse #ThreatDetection #SecurityOperations #LogAnalysis #TryHackMe #BTLO #AstraQuantumTech #CybersecurityLearning
